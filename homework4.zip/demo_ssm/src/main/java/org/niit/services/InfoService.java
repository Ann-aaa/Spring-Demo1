package org.niit.services;

public class InfoService {
	
	public void showMsg() {
		System.out.println("Hello Spring -- " + this.getClass().getName());
	}
	
}
